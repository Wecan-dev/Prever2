<section id="section05" class="about">
	<div id="about" class="about-text">
		<h2>
			<?php echo get_theme_mod('about_titulo');?>
		</h2>
		
		<p style="font-weight: bold; margin-bottom: 3%;">
		<?php echo get_theme_mod('about_subtitulo');?>

		</p>
		<p>
			<?php echo get_theme_mod('about_contenido');?>

		</p>
	</div>
	<div class="about-img">
		<img src="<?php echo get_theme_mod('about_imagen');?>" alt="">
	</div>
</section>
