<section class="noticias">
		<div class="noticias-text">
			<h2>Noticias</h2>
			<h3>Lorem ipsum is simply <br> dummy text of the print</h3>
			<p>Lorem Ipsum is simply dummy text of the printing and <br> typesetting industry. Lorem Ipsum has been the industry's <br> standard dummy text ever since the 1500s.</p>
		</div>
</section>